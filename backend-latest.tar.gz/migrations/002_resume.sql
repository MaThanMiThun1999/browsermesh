-- Checkpoints table — stores resume cursor for each job
-- The cursor is plugin-defined (page number, offset, URL, etc.)
-- Written every N rows (config.CHECKPOINT_EVERY_N_ROWS)

CREATE TABLE IF NOT EXISTS job_checkpoints (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  job_id        TEXT    NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  cursor        TEXT    NOT NULL,           -- JSON cursor object
  result_count  INTEGER NOT NULL,           -- how many results saved at this point
  saved_at      TEXT    NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_checkpoint_job
  ON job_checkpoints(job_id);              -- one active checkpoint per job
