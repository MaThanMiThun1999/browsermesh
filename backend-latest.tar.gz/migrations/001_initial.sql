CREATE TABLE IF NOT EXISTS jobs (
  id            TEXT    PRIMARY KEY,
  scraper_id    TEXT    NOT NULL,
  config        TEXT    NOT NULL,           -- JSON input config
  status        TEXT    NOT NULL DEFAULT 'pending',
                                            -- pending|running|completed
                                            -- failed|cancelled|paused
  result_count  INTEGER DEFAULT 0,
  error         TEXT,
  retry_count   INTEGER DEFAULT 0,
  created_at    TEXT    NOT NULL,
  started_at    TEXT,
  completed_at  TEXT
);

CREATE TABLE IF NOT EXISTS results (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  job_id        TEXT    NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  data          TEXT    NOT NULL,           -- JSON result row
  dedup_hash    TEXT,                       -- hash for deduplication (optional)
  created_at    TEXT    NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_results_job ON results(job_id);
CREATE INDEX IF NOT EXISTS idx_results_hash ON results(job_id, dedup_hash);

CREATE TABLE IF NOT EXISTS job_logs (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  job_id        TEXT    NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  level         TEXT    NOT NULL,           -- info|warn|error|debug
  message       TEXT    NOT NULL,
  created_at    TEXT    NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_logs_job ON job_logs(job_id);

CREATE TABLE IF NOT EXISTS app_config (
  key           TEXT    PRIMARY KEY,
  value         TEXT    NOT NULL,
  updated_at    TEXT    NOT NULL
);

CREATE TABLE IF NOT EXISTS license_cache (
  id            INTEGER PRIMARY KEY CHECK (id = 1),
  user_id       TEXT    NOT NULL,
  plan          TEXT    NOT NULL,
  entitlements  TEXT    NOT NULL,           -- JSON
  expires_at    TEXT    NOT NULL,
  updated_at    TEXT    NOT NULL
);

CREATE TABLE IF NOT EXISTS usage_log (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  scraper_id    TEXT    NOT NULL,
  result_count  INTEGER NOT NULL,
  job_id        TEXT    NOT NULL,
  synced        INTEGER DEFAULT 0,          -- 0=pending, 1=synced
  created_at    TEXT    NOT NULL
);
