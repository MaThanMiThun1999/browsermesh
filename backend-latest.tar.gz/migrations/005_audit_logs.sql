CREATE TABLE IF NOT EXISTS audit_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    level TEXT NOT NULL,
    error_message TEXT NOT NULL,
    context TEXT,
    plugin_id TEXT,
    synced INTEGER DEFAULT 0,
    created_at TEXT NOT NULL
);
