CREATE TABLE IF NOT EXISTS onboarding_status (
  id                INTEGER PRIMARY KEY CHECK (id = 1),
  db_connected      INTEGER NOT NULL DEFAULT 0,
  runtime_active    INTEGER NOT NULL DEFAULT 0,
  browser_installed INTEGER NOT NULL DEFAULT 0,
  benchmark_passed  INTEGER NOT NULL DEFAULT 0,
  is_completed      INTEGER NOT NULL DEFAULT 0,
  updated_at        TEXT    NOT NULL
);

INSERT OR IGNORE INTO onboarding_status (id, db_connected, runtime_active, browser_installed, benchmark_passed, is_completed, updated_at)
VALUES (1, 0, 0, 0, 0, 0, datetime('now'));
