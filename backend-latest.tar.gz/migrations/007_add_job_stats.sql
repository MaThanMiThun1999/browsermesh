-- Add stats columns to the jobs table for tracking throughput and performance
ALTER TABLE jobs ADD COLUMN pages_processed INTEGER DEFAULT 0;
ALTER TABLE jobs ADD COLUMN execution_speed REAL DEFAULT 0.0;
